#include "MyComplex.h"
#include <iostream>

MyComplex::MyComplex(double r, double i){ 
  real = new double(r);
  imag = new double(i);
}

MyComplex::MyComplex(const MyComplex& other){ 
  real = new double(*other.real);
  imag = new double(*other.imag);
}

MyComplex::~MyComplex(){ 
  delete real;
  delete imag;
}

MyComplex MyComplex::operator+(const MyComplex& other){ 
  MyComplex res(*real + *other.real, *imag + *other.imag);
  return res;
}

MyComplex MyComplex::operator=(const MyComplex& other){
  *real = *other.real;
  *imag = *other.imag;
  return *this;
}

void MyComplex::output(){
  std::cout << "(" << *real << " + " << *imag << "i)" << std::endl;
}

MyComplex operator+(double r, const MyComplex& other){
  MyComplex res(r + *other.real, *other.imag);
  return res;
}

MyComplex operator+(const MyComplex& other, double r){
  MyComplex res(*other.real + r, *other.imag);
  return res;
}