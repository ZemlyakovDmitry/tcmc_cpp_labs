#include "MyComplex.h"

int main(){
  MyComplex a(1, 2);
  MyComplex b(3, 4);
  MyComplex c;
  c = a + b;
  c.output();

  MyComplex d;
  d = 5 + b;
  d.output();

  MyComplex e;
  e = a + 6;
  e.output();

  return 0;
}