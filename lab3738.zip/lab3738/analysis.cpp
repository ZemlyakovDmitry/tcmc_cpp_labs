#include <iostream>
#include "analysis.h"

using namespace std;
void analyze(){
    int choice;
    while (true) {
        cout << endl << "---   Caesar analysis   ---" << endl;
        string input_filename, output_filename;
        int shift;
        cout << "Enter input filename: " << endl;
        cin >> input_filename;
        cout << "Enter file for the result: " << endl;
        cin >> output_filename;
        analyze_file(input_filename, output_filename);
        return;
    }
}

void analyze_file(const string& input_filename, const string& output_filename) {

    ifstream input_file;
    input_file.open(input_filename);
    if (!input_file.is_open()) {
        cout << "Error while trying to open input file " << input_filename << endl;
        return;
    }

    ofstream output_file;
    output_file.open(output_filename, ios::out);
    if (!output_file.is_open()) {
        cout << "Error while trying to open output file " << output_filename << endl;
        return;
    }

    string str;
    getline(input_file, str);
    for(int shift=alphabet.length();shift>0;--shift){
        output_file << shift << " - ";
        for(int i=0;i<str.length();++i){
            int pos = alphabet.find(str[i]);
            if (pos == string::npos) {
                output_file << str[i];
                continue;
            }
            pos = (pos - shift + alphabet.size()) % alphabet.size();
            output_file << alphabet[pos];
    }
    output_file << endl;
}
    input_file.close();
    output_file.close();
    cout << "Analysis of the file " << input_filename << " is writen to " << output_filename << endl << endl;
    return;
}