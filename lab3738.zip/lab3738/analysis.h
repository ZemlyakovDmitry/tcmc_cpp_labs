#ifndef ANALYSIS_H
#define ANALYSIS_H

#include <iostream>
#include <fstream>

extern const std::string alphabet; 

void analyze();
void analyze_file(const std::string& input_filename, const std::string& output_filename);

#endif // DECODE_H