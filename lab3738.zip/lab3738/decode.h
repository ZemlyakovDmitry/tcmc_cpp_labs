#ifndef DECODE_H
#define DECODE_H

#include <iostream>
#include <fstream>

extern const std::string alphabet; 

void decode();
void decode_file(const std::string& input_filename, const std::string& output_filename, int shift);

#endif // DECODE_H