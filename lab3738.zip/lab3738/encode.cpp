#include <iostream>
#include <fstream>
#include "encode.h"

using namespace std;

void encoder_menu() {
    string input_filename, output_filename;
    int shift;
    cout << endl << "---   Caesar encode   ---" << endl;
    cout << "Enter input filename: " << endl;
    cin >> input_filename;
    cout << "Enter file for the result: " << endl;
    cin >> output_filename;
    cout << "Enter shift: " << endl;
    cin >> shift;
/*   if (shift>26){
        cout << "Shift is too big. Maximum is 26." << endl;
        return;
    } */
    encrypt_file(input_filename, output_filename, shift);
}

void encrypt_file(const string& input_filename, const string& output_filename, int shift) {

    ifstream input_file;
    input_file.open(input_filename);
    if (!input_file.is_open()) {
        cout << "Error while trying to open input file " << input_filename << endl;
        return;
    }

    ofstream output_file;
    output_file.open(output_filename, ios::out);
    if (!output_file.is_open()) {
        cout << "Error while trying to open output file " << output_filename << endl;
        return;
    }

    char c;
    while (input_file.get(c)) {
        int pos = alphabet.find(c);
        if (pos == string::npos) {
            output_file << c;
            continue;
        }
        pos = (pos + shift) % alphabet.size();
        output_file << alphabet[pos];
    }
    input_file.close();
    output_file.close();
    cout << "File " << input_filename << " successfully encoded and output writen to " << output_filename << endl << endl;
    return;
}
