#ifndef ENCODE_H
#define ENCODE_H

#include <iostream>
#include <fstream>

extern const std::string alphabet; 

void encoder_menu();
void encrypt_file(const std::string& input_filename, const std::string& output_filename, int shift);

#endif // ENCODE_H