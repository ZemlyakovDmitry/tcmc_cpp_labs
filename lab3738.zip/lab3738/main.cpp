#include <iostream>
#include "encode.h"
#include "decode.h"
#include "analysis.h"
using namespace std;

extern const string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";


int main(){
    cout << "Zemlyakov 9i-21 lab 37-38" << endl << endl;
    int choice = -1;
    while (choice != 0) {
        cout << endl << "---   Lab 37-38   ---" << endl;
        cout << "Choise your action:" << endl;
        cout << "[0] - Exit " << endl;
        cout << "[1] - Caesar encode " << endl;
        cout << "[2] - Caesar decode " << endl;
        cout << "[3] - Analysis " << endl;
        cin >> choice;
        switch (choice) {
            case 0:
                cout << "bb" << endl;
                break;
            case 1:
                encoder_menu();
                break;
            case 2:
                decode();
                break;
            case 3:
                analyze();
                break;
            default:
                cout << "Incorrect input" << endl;
                break;
        }
    }
    return 0;
}