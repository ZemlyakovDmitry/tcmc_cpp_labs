#include "decode.h"
#include <iostream>
#include <fstream>

using namespace std;

string decode_string(const string& text, const string& key, const Vigenere_square& vs)
{
    string decodedText;
    string key2 = key;

    while (key2.length() < text.length())
        key2 += key;

    for (size_t k = 0; k < text.length(); k++)
    {
        if (isalpha(text[k]) == false)
            decodedText += text[k];
        else {
            size_t row = vs.ALPHABET.find(key2[k]);
            size_t column = 0;
            for (size_t i = 0; i < vs.size; i++)
            {
                if (vs.array[i][row] == text[k])
                {
                    column = i;
                    break;
                }
            }
            if (row < vs.size && column < vs.size)
                decodedText += vs.ALPHABET[column];
        }
    }

    return decodedText;
}



void decode_file()
{
    cout << "Enter input filename: ";
    string inputFileName;
    cin >> inputFileName;
    ifstream inputFile(inputFileName);

    cout << "Enter output filename: ";
    string outputFileName;
    cin >> outputFileName;
    ofstream outputFile(outputFileName);
    if (!inputFile)
    {
        cout << "Error while openning file " << inputFileName << endl;
        return;
    }
    if (!outputFile)
    {
        cout << "Error while openning file " << outputFileName << endl;
        return;
    }

    string key;
    cout << "Enter key: ";
    cin >> key;

    Vigenere_square vs;

    string line;
    while (getline(inputFile, line))
    {
        outputFile << decode_string(line, key, vs) << endl;
    }

    inputFile.close();
    outputFile.close();

    cout << "File " << outputFileName << " has been successfully written" << endl << endl;
}
