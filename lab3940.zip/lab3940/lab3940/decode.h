#ifndef DECODE_H
#define DECODE_H

#include "vigenere.h"

using namespace std;

string decode_string(const string& text, const string& key, const Vigenere_square& vs);
void decode_file();

#endif