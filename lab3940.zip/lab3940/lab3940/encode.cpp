#include "encode.h"
#include <iostream>
#include <fstream>

using namespace std;

string encode_string(const string& text, const string& key, const Vigenere_square& vs)
{
    string text2 = text;
    string key2 = key;
    while (text2.length() > key2.length())
        key2 += key;

    string encodedText;
    size_t k = 0;
    for (char c : text2)
    {
        size_t row = vs.ALPHABET.find(key2[k]);
        size_t column = vs.ALPHABET.find(c);

        if (row < vs.size && column < vs.size)
            encodedText += vs.array[row][column];
        else
            encodedText += c;

        k++;
    }

    return encodedText;
}

void encode_file()
{
    cout << "Enter input filename: ";
    string inputFileName, outputFileName;
    cin >> inputFileName;

    ifstream inputFile(inputFileName);
    if (!inputFile)
    {
        cout << "Error while openning file " << inputFileName << endl;
        return;
    }

    cout << "Enter output filename: ";

    cin >> outputFileName;
    ofstream outputFile(outputFileName);
    if (!outputFile)
    {
        cout << "Error while openning file " << outputFileName << endl;
        return;
    }

    string key;
    cout << "Enter key: ";
    cin >> key;

    Vigenere_square vs;

    string line;
    while (getline(inputFile, line))
    {
        outputFile << encode_string(line, key, vs) << endl;
    }

    inputFile.close();
    outputFile.close();

    cout << "File " << outputFileName << " has been successfully written" << endl << endl;
}
