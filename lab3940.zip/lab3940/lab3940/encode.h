#ifndef ENCODE_H
#define ENCODE_H

#include "vigenere.h"

using namespace std;

string encode_string(const string& text, const string& key, const Vigenere_square& vs);
void encode_file();

#endif
