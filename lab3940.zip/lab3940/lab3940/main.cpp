#include "encode.h"
#include "decode.h"
#include "output.h"
#include <iostream>

int main()
{
    using namespace std;
    cout << "Zemlyakov 9i-21" << endl << endl;
    while (true)
    {
        cout << "Menu:\n"
            << "1. Encode file \n"
            << "2. Decode file\n"
            << "3. Print Vigenere square\n"
            << "0. Exit\n"
            << "Choise your action: ";

        int choice;
        cin >> choice;

        switch (choice)
        {
        case 1:
            encode_file();
            break;
        case 2:
            decode_file();
            break;
        case 3:
            output_square();
            break;
        case 0:
            cout << "bb";
            return 0;
        default:
            cout << "Wrong choise." << endl;
            break;
        }
    }
}
