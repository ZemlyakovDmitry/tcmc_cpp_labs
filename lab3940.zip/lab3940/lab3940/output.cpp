#include "output.h"
#include <iostream>
#include <fstream>

using namespace std;

ostream& operator<<(ostream& os, const Vigenere_square& vs)
{
    for (size_t i = 0; i < vs.size; i++)
    {
        for (size_t j = 0; j < vs.size; j++)
        {
            os << vs.array[i][j] << " ";
        }
        os << endl;
    }

    return os;
}

void output_square()
{
    cout << "Enter output filename: ";
    string outputFileName;
    cin >> outputFileName;

    ofstream outputFile(outputFileName);

    if (!outputFile)
    {
        cout << "Error while openning file " << outputFileName << endl;
        return;
    }

    Vigenere_square vs;

    outputFile << "Vigenere square:\n";
    outputFile << vs;

    outputFile.close();

    cout << "File " << outputFileName << " has been successfully written" << endl << endl;
}
