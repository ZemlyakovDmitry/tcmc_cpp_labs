#ifndef OUTPUT_H
#define OUTPUT_H

#include "vigenere.h"
#include <ostream>

using namespace std;

ostream& operator<<(ostream& os, const Vigenere_square& vs);
void output_square();

#endif
