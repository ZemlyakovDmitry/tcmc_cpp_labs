#include "vigenere.h"

using namespace std;

Vigenere_square::Vigenere_square()
{
    size = ALPHABET.length() + 1;
    array = new char* [size];
    for (size_t i = 0; i < size; i++)
        array[i] = new char[size];

    string alphabet2 = " " + ALPHABET;
    for (size_t i = 0; i < size; i++)
    {
        for (size_t j = 0; j < size; j++)
            array[i][j] = alphabet2[j];

        alphabet2 += alphabet2[1];
        alphabet2.erase(0, 1);
    }
}

Vigenere_square::~Vigenere_square()
{
    for (size_t i = 0; i < size; i++)
        delete[] array[i];
    delete[] array;
}
