#ifndef VIGENERE_H
#define VIGENERE_H

#include <string>

using namespace std;

class Vigenere_square
{
private:
    const string ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    size_t size;
    char** array;

public:
    Vigenere_square();

    ~Vigenere_square();

    friend string encode_string(const string& text, const string& key, const Vigenere_square& vs);
    friend string decode_string(const string& text, const string& key, const Vigenere_square& vs);
    friend ostream& operator<<(ostream& os, const Vigenere_square& vs);
};

#endif
